"""
Step 1: Get a power flow solver running locally.

Loads the IEEE 14-bus test case, runs a Newton-Raphson AC power flow
using pandapower, and prints/saves the ground-truth (P, Q, V, theta)
values per bus. These are exactly the four node variables (p_i, q_i,
v_i, delta_i) that the Joule GridFM paper models as graph node features.
"""

import pandapower as pp
import pandapower.networks as pn
import pandas as pd

# 1. Load a standard IEEE test case (built into pandapower)
net = pn.case14()

# 2. Run Newton-Raphson AC power flow
pp.runpp(net, algorithm="nr")

# 3. Inspect the solved state -- this IS the ground truth a GNN will
#    later be trained to reconstruct/predict.
bus_results = net.res_bus.copy()
bus_results.index.name = "bus_id"
bus_results = bus_results.rename(columns={
    "p_mw": "P (MW)",
    "q_mvar": "Q (MVAr)",
    "vm_pu": "V (p.u.)",
    "va_degree": "theta (deg)",
})

print("=== IEEE 14-bus: solved power flow (per bus) ===")
print(bus_results.round(4).to_string())

print("\n=== Line loading (top 5 most loaded lines) ===")
line_results = net.res_line[["p_from_mw", "q_from_mvar", "loading_percent"]]
print(line_results.sort_values("loading_percent", ascending=False).head(5).round(3))

print(f"\nConverged: {net['converged']}")
print(f"Number of buses: {len(net.bus)}")
print(f"Number of lines/transformers: {len(net.line) + len(net.trafo)}")

# 4. Save the node-feature table -- this is the exact CSV shape you'll
#    later turn into a PyTorch Geometric graph in Step 2.
bus_results.to_csv("/mnt/user-data/outputs/ieee14_bus_powerflow.csv")

# 5. Also save the edge list (from_bus, to_bus, plus line params) --
#    this becomes your graph connectivity in Step 2.
edges = net.line[["from_bus", "to_bus", "r_ohm_per_km", "x_ohm_per_km", "length_km"]].copy()
edges.to_csv("/mnt/user-data/outputs/ieee14_edges.csv", index=False)

print("\nSaved: ieee14_bus_powerflow.csv (node features), ieee14_edges.csv (graph edges)")
